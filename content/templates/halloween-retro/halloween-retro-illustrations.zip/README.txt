Halloween Retro – illustrations
================================

The four screens of the Halloween Retro as PNG images (1920x1080), one per
phase, for rebuilding the retro in any whiteboard tool:

  halloween-retro-1-stop-doing.png     grumpy pumpkin   – rotten tomatoes
  halloween-retro-2-proceed-doing.png  happy pumpkin    – chocolate bars
  halloween-retro-3-ideas.png          witch's broom    – idea flashes
  halloween-retro-4-to-dos.png         cauldron         – to-dos

The complete template for NeoBoard (with card stacks and instructions):
https://neoboard.io/en/templates/halloween-retro/

License: CC0 1.0 (public domain) – copy, adapt and use them for any purpose,
even commercially, without asking and without attribution.
https://creativecommons.org/publicdomain/zero/1.0/

Made by Nordeck IT + Consulting GmbH – https://neoboard.io
